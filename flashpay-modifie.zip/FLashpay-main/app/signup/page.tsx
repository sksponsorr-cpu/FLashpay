import AuthPage from "@/app/auth-page";

export default function SignupPage() {
  return <AuthPage initialMode="signup" />;
}
